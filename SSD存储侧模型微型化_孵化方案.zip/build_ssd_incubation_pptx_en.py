# -*- coding: utf-8 -*-
"""
Generate English version: "Putting AI Inside the SSD" incubation deck
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from lxml import etree

# ---------------- palette ----------------
NAVY  = RGBColor(0x1B, 0x2A, 0x4A)
NAVY2 = RGBColor(0x24, 0x37, 0x5E)
BLUE  = RGBColor(0x2E, 0x75, 0xB6)
SKY   = RGBColor(0x00, 0xB0, 0xF0)
TEAL  = RGBColor(0x0E, 0x9F, 0x8A)
GREEN = RGBColor(0x2E, 0x9E, 0x6B)
RED   = RGBColor(0xC0, 0x50, 0x4D)
AMBER = RGBColor(0xD9, 0x82, 0x2B)
BG    = RGBColor(0xF4, 0xF7, 0xFB)
CARD  = RGBColor(0xFF, 0xFF, 0xFF)
DARK  = RGBColor(0x23, 0x2B, 0x36)
GRAY  = RGBColor(0x5A, 0x64, 0x72)
LIGHT = RGBColor(0xD7, 0xE1, 0xEC)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Calibri"
W, H = Inches(13.333), Inches(7.5)

prs = Presentation()
prs.slide_width = W
prs.slide_height = H
BLANK = prs.slide_layouts[6]

# ---------------- helpers ----------------
def set_font(run, size=18, bold=False, color=DARK, italic=False, name=FONT):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = name
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find(qn('a:ea'))
    if ea is None:
        ea = etree.SubElement(rPr, qn('a:ea'))
    ea.set('typeface', name)

def no_shadow(shape):
    shape.shadow.inherit = False

def rect(slide, x, y, w, h, fill, line=None, line_w=1.0, shape=MSO_SHAPE.RECTANGLE):
    s = slide.shapes.add_shape(shape, x, y, w, h)
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = Pt(line_w)
    no_shadow(s)
    return s

def add_box(slide, x, y, w, h, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = Pt(2)
    tf.margin_right = Pt(2)
    tf.margin_top = Pt(2)
    tf.margin_bottom = Pt(2)
    return tf

def para(tf, first=False, align=PP_ALIGN.LEFT, space_after=0, space_before=0, line_spacing=1.0):
    p = tf.paragraphs[0] if first else tf.add_paragraph()
    p.alignment = align
    p.space_after = Pt(space_after)
    p.space_before = Pt(space_before)
    p.line_spacing = line_spacing
    return p

def run(p, text, size=18, bold=False, color=DARK, italic=False):
    r = p.add_run()
    r.text = text
    set_font(r, size, bold, color, italic)
    return r

def bullets(tf, items, size=15, gap=5, bcolor=SKY, bullet="\u2022", color=DARK, line_spacing=1.05):
    first = True
    for it in items:
        p = para(tf, first=first, space_after=gap, line_spacing=line_spacing)
        first = False
        run(p, bullet + "  ", size, True, bcolor)
        if isinstance(it, tuple):
            run(p, it[0], size, it[1], color)
        else:
            run(p, it, size, False, color)
    return tf

def header(slide, title, num, kicker=None):
    rect(slide, 0, 0, W, H, BG)
    bar = rect(slide, 0, 0, W, Inches(1.02), NAVY)
    tf = bar.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.margin_left = Inches(0.55)
    tf.margin_right = Inches(0.55)
    tf.margin_top = Inches(0.02)
    tf.margin_bottom = Inches(0.02)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    run(p, title, 24, True, WHITE)
    if kicker:
        run(p, "    " + kicker, 13, False, RGBColor(0xC7, 0xD4, 0xE6))
    rect(slide, 0, Inches(1.02), W, Pt(3), SKY)
    ft = add_box(slide, Inches(0.55), Inches(7.1), Inches(8), Inches(0.32))
    run(para(ft, first=True), "SSD-side Model Miniaturization \u00b7 Incubation Proposal", 10, False, GRAY)
    pg = add_box(slide, Inches(12.3), Inches(7.1), Inches(0.75), Inches(0.32))
    run(para(pg, first=True, align=PP_ALIGN.RIGHT), str(num), 10, False, GRAY)

def card(slide, x, y, w, h, head, hcolor, items, size=15, gap=5, head_size=None):
    rect(slide, x, y, w, h, CARD, line=LIGHT, line_w=1.0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    hs = head_size if head_size else size + 2
    ht = add_box(slide, x + 0.28, y + 0.13, w - 0.56, Inches(0.45))
    run(para(ht, first=True), head, hs, True, hcolor)
    rect(slide, x + 0.28, y + 0.58, w - 0.56, Pt(2.5), hcolor)
    bt = add_box(slide, x + 0.28, y + 0.68, w - 0.56, h - 0.8)
    bullets(bt, items, size=size, gap=gap, bcolor=hcolor)
    return bt

def stat_card(slide, x, y, w, h, big, label, color):
    rect(slide, x, y, w, h, CARD, line=LIGHT, line_w=1.0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(slide, x, y, w, Pt(5), color)
    tf = add_box(slide, x + 0.2, y + 0.22, w - 0.4, h - 0.3)
    run(para(tf, first=True, align=PP_ALIGN.CENTER), big, 25, True, color)
    run(para(tf, align=PP_ALIGN.CENTER, space_before=3), label, 12, False, GRAY)

# ============================================================
# Slide 1 — Cover
# ============================================================
s = prs.slides.add_slide(BLANK)
rect(s, 0, 0, W, H, NAVY)
rect(s, 0, 0, W, Inches(0.22), SKY)
rect(s, 0, H - Inches(0.22), W, Inches(0.22), SKY)
rect(s, Inches(0.9), Inches(2.35), Inches(0.9), Pt(4), SKY)

tf = add_box(s, Inches(0.9), Inches(2.6), Inches(11.5), Inches(2.2))
run(para(tf, first=True), "Putting AI Inside the SSD", 54, True, WHITE)
run(para(tf, space_before=6), "Storage-side model miniaturization \u2014 turning SSDs from \u201cstoring data\u201d into \u201cunderstanding data\u201d", 24, False, RGBColor(0xCF, 0xDE, 0xF0))

tf = add_box(s, Inches(0.9), Inches(4.9), Inches(11.5), Inches(0.6))
run(para(tf, first=True), "An Incubation Proposal for Internal Review", 18, True, SKY)

tf = add_box(s, Inches(0.9), Inches(6.35), Inches(11.5), Inches(0.6))
run(para(tf, first=True), "Presenter: ____________       Department: ____________       Date: ____________ 2026", 14, False, RGBColor(0x9A, 0xAC, 0xC4))

# ============================================================
# Slide 2 — Agenda
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Agenda \u00b7 Proposal Overview", 2)
items = [
    ("01", "Background & Problem", "Data explosion and the \u201cdata movement\u201d bottleneck"),
    ("02", "Market & Technology Landscape", "Market size, players, standards, and model compression"),
    ("03", "Existing Solutions: Pros & Cons", "What the industry got right, and the pain points left open"),
    ("04", "Our Solution & Improvements", "An integrated miniaturize-and-deploy pipeline for SSDs"),
    ("05", "Feasibility", "Why this can be done: technical and ecosystem rationale"),
    ("06", "Value & Returns", "Impact if successful; assets retained even if not"),
    ("07", "Roadmap & Resources", "Phased execution plan and resource needs"),
    ("08", "Summary & Ask", "One-line pitch plus what we ask the company"),
]
x0, y0, cw, ch, gap = Inches(0.7), Inches(1.42), Inches(5.9), Inches(1.28), Inches(0.12)
for i, (no, t, d) in enumerate(items):
    col = i % 2
    row = i // 2
    x = x0 + col * (cw + gap)
    y = y0 + row * (ch + gap)
    rect(s, x, y, cw, ch, CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, x, y, Inches(0.12), ch, SKY if col == 0 else TEAL)
    tf = add_box(s, x + 0.32, y + 0.12, cw - 0.55, ch - 0.2)
    run(para(tf, first=True), no, 18, True, SKY if col == 0 else TEAL)
    run(para(tf, space_before=2), "  " + t, 15, True, DARK)
    run(para(tf, space_before=2), d, 11, False, GRAY)

# ============================================================
# Slide 3 — Background & Problem
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Background & Problem", 3, "Why \u201cstorage-side AI\u201d")
card(s, Inches(0.6), Inches(1.45), Inches(4.0), Inches(5.15), "Data Side", SKY, [
    "Unstructured data is exploding: video, logs, sensors, vector search",
    "AI inference is moving to the edge and storage, not just the central cloud",
    "Massive raw data sits idle and unprocessed \u2014 value buried",
], size=15, gap=8)
card(s, Inches(4.72), Inches(1.45), Inches(4.0), Inches(5.15), "Architectural Pain", RED, [
    "SSD \u2192 RAM \u2192 CPU/GPU movement brings a triple cost: latency / bandwidth / power",
    "Many \u201cin-place filter / feature-extraction\u201d tasks are forced to ship everything back to the host",
    "Compute sits too far from data \u2014 high TCO, poor real-time response",
], size=15, gap=8)
card(s, Inches(8.84), Inches(1.45), Inches(3.9), Inches(5.15), "Core Opportunity", GREEN, [
    "Deploy miniaturized models directly onto SSD compute engines for in-place inference",
    "Storage upgrades from \u201cpassively storing\u201d to \u201cactively understanding\u201d data",
    "Gives the company a differentiated position in the computational-storage race",
], size=15, gap=8)

# ============================================================
# Slide 4 — Market & Technology (1)
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Market & Technology (1): The Computational Storage Race", 4)
stat_card(s, Inches(0.6), Inches(1.35), Inches(4.0), Inches(1.55), "$704M", "Global computational-storage market, 2025", BLUE)
stat_card(s, Inches(4.72), Inches(1.35), Inches(4.0), Inches(1.55), "$1.96B", "Projected market, 2032", TEAL)
stat_card(s, Inches(8.84), Inches(1.35), Inches(3.9), Inches(1.55), "15.9% CAGR", "CAGR 2026\u20132032", GREEN)

lf = add_box(s, Inches(0.6), Inches(3.2), Inches(6.6), Inches(3.7))
run(para(lf, first=True), "The race is heating up \u2014 but the \u201cmodel\u201d piece is missing", 17, True, NAVY)
bullets(lf, [
    "Key players: Samsung, ScaleFlux, Marvell, Phison, Kioxia, Pliops, Eideticom, DapuStor, Huawei, Union Memory, and others",
    "Standards: SNIA defines CSD / CSP, splitting FCSS (fixed-function) and PCSS (programmable)",
    "SNIA launched Storage.AI in 2025, targeting open standards for AI data services",
    "Applications: data centers, smart cameras, log/retrieval analytics, AI data services",
], size=14, gap=7)

cd = CategoryChartData()
cd.categories = ["2025", "2032"]
cd.add_series("Market size (USD M)", (704, 1960))
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(7.5), Inches(3.15), Inches(5.1), Inches(3.6), cd)
ch = gf.chart
ch.has_legend = False
ch.has_title = False
plot = ch.plots[0]
plot.gap_width = 120
ser = plot.series[0]
ser.format.fill.solid()
ser.format.fill.fore_color.rgb = BLUE
plot.vary_by_categories = False
cat_ax = ch.category_axis
cat_ax.tick_labels.font.size = Pt(12)
cat_ax.tick_labels.font.name = FONT
val_ax = ch.value_axis
val_ax.tick_labels.font.size = Pt(11)
val_ax.has_major_gridlines = True
tf = add_box(s, Inches(7.5), Inches(6.75), Inches(5.1), Inches(0.3))
run(para(tf, first=True, align=PP_ALIGN.CENTER), "Source: LP Information / QYResearch computational-storage market reports", 9.5, False, GRAY)

# ============================================================
# Slide 5 — Market & Technology (2)
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Market & Technology (2): Technology Landscape", 5)
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(2.6), "Computational Storage Hardware", SKY, [
    "FPGA / ASIC accelerators integrated into SSDs or storage controllers, computing near NAND",
    "Examples: Samsung SmartSSD (FPGA), ScaleFlux, Pliops, DapuStor, and more",
], size=14, gap=6)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(2.6), "Software & Service Standards", BLUE, [
    "FCSS: fixed functions (compression / encryption / filtering / retrieval)",
    "PCSS: programmable compute services with custom operators",
], size=14, gap=6)
card(s, Inches(0.6), Inches(4.2), Inches(6.0), Inches(2.6), "Model Miniaturization (Model Side)", TEAL, [
    "Quantization (INT8 / INT4), pruning, knowledge distillation",
    "Lightweight architectures (YOLO / MobileNet), NAS architecture search",
], size=14, gap=6)
card(s, Inches(6.85), Inches(4.2), Inches(5.9), Inches(2.6), "Key Insight \u2014 Our Entry Point", AMBER, [
    "Hardware has compute but no models; models are compressed but not deployed",
    "No systematic bridge between the two \u2014 exactly the gap our solution fills",
], size=14, gap=6)

# ============================================================
# Slide 6 — Pros & Cons
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Existing Solutions: Pros & Cons", 6)
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(5.35), "Pros \u2014 Value the Industry Has Validated", GREEN, [
    "In-place processing cuts data movement \u2192 lower latency, less bandwidth",
    "Offloads the host CPU, lowering energy and TCO",
    "Data never leaves the drive \u2014 better privacy and compliance",
    "Close to the data source \u2014 ideal for filtering / retrieval / feature extraction",
    "Commercial products and standards already back the approach",
], size=15, gap=9)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(5.35), "Cons & Pain Points \u2014 The Unsolved Problems", RED, [
    "High hardware cost, fragmented ecosystem, proprietary SDKs, hard to migrate",
    "Weak in-drive compute, small memory, tight power budget \u2014 large models don\u2019t fit",
    "No mature \u201cmodel \u2192 storage-compute-engine\u201d deployment toolchain",
    "SmartSSD reference case underperformed commercially; hype was diluted by generative AI",
], size=15, gap=9)

# ============================================================
# Slide 7 — Our Solution & Improvements
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Our Solution & Improvements", 7)
bar = rect(s, Inches(0.6), Inches(1.35), Inches(12.13), Inches(1.0), NAVY2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(1.4), Inches(11.6), Inches(0.9), anchor=MSO_ANCHOR.MIDDLE)
p = para(tf, first=True)
run(p, "In brief:  ", 15, True, SKY)
run(p, "an integrated \u201cmodel miniaturization + automated deployment\u201d pipeline for SSD storage-compute engines, customizing any model into a lightweight one that runs real-time inference inside the drive.", 15, False, WHITE)

card(s, Inches(0.6), Inches(2.55), Inches(6.0), Inches(2.25), "1. Hardware-Aware Automated Miniaturization", SKY, [
    "Quantization + pruning + distillation + NAS, tuned to a specific SSD\u2019s compute / memory / power budget",
], size=13.5, gap=4)
card(s, Inches(6.85), Inches(2.55), Inches(5.9), Inches(2.25), "2. Unified IR & Runtime", BLUE, [
    "Abstracts hardware differences: compress once, deploy everywhere, no proprietary SDK lock-in",
], size=13.5, gap=4)
card(s, Inches(0.6), Inches(4.95), Inches(6.0), Inches(1.9), "3. Multi-Objective Joint Optimization", TEAL, [
    "Jointly optimizes accuracy \u2013 latency \u2013 energy; measurable and reproducible",
], size=13.5, gap=4)
card(s, Inches(6.85), Inches(4.95), Inches(5.9), Inches(1.9), "4. Tiered Hybrid Inference", GREEN, [
    "Light tasks infer in-place; heavy tasks fall back to the host to guarantee accuracy",
], size=13.5, gap=4)

# ============================================================
# Slide 8 — Feasibility
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Feasibility", 8, "Why this can be done")
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(2.55), "Technically Feasible", SKY, [
    "Quantization / pruning / distillation are mature: 2\u20134\u00d7 compression with controlled accuracy loss",
    "TinyML has proven mW-level on-device inference is viable",
], size=14, gap=6)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(2.55), "Hardware-Ready", BLUE, [
    "SSD controllers keep gaining compute (multi-core ARM / NPU) and can now run lightweight models",
    "Storage vendors are accelerating on-board accelerators",
], size=14, gap=6)
card(s, Inches(0.6), Inches(4.15), Inches(6.0), Inches(2.55), "Real Demand", TEAL, [
    "In-place filtering / feature extraction is a universal need in databases, retrieval, security monitoring",
    "Customers will pay for \u201cless bandwidth, lower latency, privacy\u201d",
], size=14, gap=6)
card(s, Inches(6.85), Inches(4.15), Inches(5.9), Inches(2.55), "Favorable Ecosystem", GREEN, [
    "SNIA standards lower integration barriers; we can reuse our model-side assets",
    "First movers can build a toolchain moat",
], size=14, gap=6)

# ============================================================
# Slide 9 — Impact If Successful
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Impact If Successful", 9, "What we gain if it works")
card(s, Inches(0.6), Inches(1.4), Inches(4.0), Inches(3.5), "Business Value", SKY, [
    "New product form: smart SSD / computational-storage service",
    "A differentiator in a fiercely competitive storage market",
], size=14, gap=7)
card(s, Inches(4.72), Inches(1.4), Inches(4.0), Inches(3.5), "Technical Value", BLUE, [
    "End-to-end miniaturization toolchain becomes core IP",
    "Transferable to phones, IoT, edge servers, and more",
], size=14, gap=7)
card(s, Inches(8.84), Inches(1.4), Inches(3.9), Inches(3.5), "Commercial Value", GREEN, [
    "Enter the fast-growing computational-storage market (15.9% CAGR)",
    "Seize the \u201cmodel + storage\u201d first-mover advantage and build a moat",
], size=14, gap=7)

rect(s, Inches(0.6), Inches(5.0), Inches(12.13), Inches(1.78), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(5.12), Inches(11.6), Inches(1.55))
run(para(tf, first=True), "Quantified expectations (illustrative, pending benchmarks)", 15, True, NAVY)
bullets(tf, [
    ("Data movement down significantly", True),
    ("End-to-end latency down", True),
    ("Host CPU load down", True),
    ("Total cost of ownership (TCO) down", True),
    ("Accuracy loss controlled (hybrid inference fallback)", True),
], size=13, gap=1, bcolor=SKY)

# ============================================================
# Slide 10 — What We Gain Even If It Fails
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "What We Gain Even If It Fails", 10, "A failure that still returns assets")
rows = [
    ("Reusable Assets", "Quantization / pruning / distillation / NAS toolchain, directly transferable to phones, IoT, edge servers, and more", SKY),
    ("Methodology", "Near-storage / computational-storage co-design experience and selection criteria, avoiding repeated missteps", BLUE),
    ("Decision Evidence", "Clear \u201cwhat works / what doesn\u2019t\u201d boundaries, informing future investment direction", TEAL),
    ("Industry Positioning", "Papers / patents / standards participation, building influence and voice", GREEN),
    ("Team Growth", "Cross-domain capability in algorithms \u00d7 storage \u00d7 firmware, with high talent reusability", AMBER),
]
y = 1.4
for name, desc, col in rows:
    rect(s, Inches(0.6), Inches(y), Inches(12.13), Inches(1.0), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, Inches(0.6), Inches(y), Inches(0.14), Inches(1.0), col)
    tf = add_box(s, Inches(1.0), Inches(y + 0.14), Inches(2.9), Inches(0.75), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf, first=True), name, 15, True, col)
    tf2 = add_box(s, Inches(4.05), Inches(y + 0.12), Inches(8.4), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf2, first=True), desc, 13, False, DARK)
    y += 1.12

# ============================================================
# Slide 11 — Roadmap & Resources
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Roadmap & Resources", 11)
phases = [
    ("Phase 0", "1\u20132 mo", "Research & Feasibility", "Lock target SSD platform and high-value scenarios; produce a feasibility verdict", SKY),
    ("Phase 1", "3\u20136 mo", "Prototype", "Run the full \u201cminiaturize \u2192 deploy \u2192 in-drive inference\u201d pipeline", BLUE),
    ("Phase 2", "6\u20139 mo", "Benchmark & Tune", "Deliver a demo plus complete performance / accuracy data", TEAL),
    ("Phase 3", "9\u201312 mo", "Productize & Pilot", "Integrate into the product line; validate with pilot customers", GREEN),
]
x0, cw, ch, gap = Inches(0.6), Inches(2.92), Inches(3.2), Inches(0.15)
for i, (ph, tm, t, d, col) in enumerate(phases):
    x = x0 + i * (cw + gap)
    rect(s, x, Inches(1.45), cw, ch, CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, x, Inches(1.45), cw, Inches(0.62), col)
    tf = add_box(s, x + 0.16, Inches(1.5), cw - 0.32, Inches(0.5))
    run(para(tf, first=True), ph + "  \u00b7  " + tm, 15, True, WHITE)
    tf = add_box(s, x + 0.16, Inches(2.25), cw - 0.32, Inches(0.5))
    run(para(tf, first=True), t, 16, True, DARK)
    tf = add_box(s, x + 0.16, Inches(2.75), cw - 0.32, Inches(1.7))
    run(para(tf, first=True), d, 12, False, GRAY)

rect(s, Inches(0.6), Inches(5.0), Inches(12.13), Inches(1.75), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(5.15), Inches(11.6), Inches(1.5))
run(para(tf, first=True), "Resource Needs", 16, True, NAVY)
bullets(tf, [
    "Team: a small cross-functional incubation group (algorithms + storage firmware + systems, ~5\u20138 people)",
    "Budget: prototype and compute resources + base operating costs, released per phase review",
    "Governance: clear milestones and go / no-go gates at each phase",
], size=13.5, gap=5, bcolor=SKY)

# ============================================================
# Slide 12 — Risks & Mitigations
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "Risks & Mitigations", 12)
rows_data = [
    ("Risk", "Impact", "Mitigation"),
    ("Fragmented hardware ecosystem", "High", "Abstract via SNIA standards + unified IR; focus on mainstream platforms"),
    ("Accuracy loss after miniaturization", "Med", "Multi-objective optimization + tiered hybrid fallback; measurable and controllable"),
    ("Long commercialization cycle", "Med", "Focus first on high-value scenarios (retrieval / log analytics / security monitoring) for fast validation"),
    ("Resource & schedule constraints", "Med", "Phased delivery, milestone reviews, fast kill-switch mechanism"),
]
tbl_shape = s.shapes.add_table(5, 3, Inches(0.6), Inches(1.5), Inches(12.13), Inches(4.4))
tbl = tbl_shape.table
tbl.columns[0].width = Inches(3.3)
tbl.columns[1].width = Inches(1.6)
tbl.columns[2].width = Inches(7.23)
for r in range(5):
    tbl.rows[r].height = Inches(0.75 if r == 0 else 0.92)
for r, row in enumerate(rows_data):
    for c, val in enumerate(row):
        cell = tbl.cell(r, c)
        cell.margin_left = Inches(0.15)
        cell.margin_right = Inches(0.1)
        cell.margin_top = Inches(0.05)
        cell.margin_bottom = Inches(0.05)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        if r == 0:
            cell.fill.solid(); cell.fill.fore_color.rgb = NAVY
            run(p, val, 15, True, WHITE)
        else:
            cell.fill.solid(); cell.fill.fore_color.rgb = WHITE if r % 2 == 1 else RGBColor(0xEE, 0xF3, 0xF9)
            if c == 1:
                p.alignment = PP_ALIGN.CENTER
                col = RED if val == "High" else AMBER
                run(p, val, 14, True, col)
            elif c == 0:
                run(p, val, 14, True, DARK)
            else:
                run(p, val, 13, False, DARK)

# ============================================================
# Slide 13 — Summary & Ask
# ============================================================
s = prs.slides.add_slide(BLANK)
rect(s, 0, 0, W, H, NAVY)
rect(s, 0, 0, W, Inches(0.22), SKY)
tf = add_box(s, Inches(0.9), Inches(1.15), Inches(11.5), Inches(1.9))
run(para(tf, first=True), "The One-Line Pitch", 15, True, SKY)
run(para(tf, space_before=10), "Model miniaturization completes the last piece of computational storage \u2014", 30, True, WHITE)
run(para(tf), "turning the SSD from \u201cstoring data\u201d into \u201cunderstanding data.\u201d", 30, True, WHITE)

tf = add_box(s, Inches(0.9), Inches(3.5), Inches(11.5), Inches(0.5))
run(para(tf, first=True), "What We Ask the Company", 15, True, SKY)

asks = [
    "Approve the project and form a small incubation team (algorithms + storage firmware + systems)",
    "Provide budget, compute, and prototype hardware",
    "Set milestone reviews (Phase 1 prototype / Phase 2 demo) with go / no-go gates",
]
y = 4.05
for i, a in enumerate(asks):
    rect(s, Inches(0.9), Inches(y), Inches(11.5), Inches(0.72), NAVY2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf = add_box(s, Inches(1.2), Inches(y + 0.08), Inches(11.0), Inches(0.56), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf, first=True), f"{i+1}.  {a}", 16, False, WHITE)
    y += 0.86

tf = add_box(s, Inches(0.9), Inches(6.7), Inches(11.5), Inches(0.5))
run(para(tf, first=True), "Thank you \u2014 we look forward to your feedback", 16, True, SKY)

# ---------------- save ----------------
prs.core_properties.title = "SSD-side Model Miniaturization \u00b7 Incubation Proposal"
prs.core_properties.author = "Incubation Team"
prs.core_properties.subject = "Computational storage + model miniaturization incubation proposal"
out = "SSD_Model_Miniaturization_Incubation_EN.pptx"
prs.save(out)
print("saved:", out, "slides:", len(prs.slides.__iter__.__self__._sldIdLst))
