# -*- coding: utf-8 -*-
"""
生成《SSD 存储侧模型微型化》孵化方案 PPT
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from lxml import etree

# ---------------- palette ----------------
NAVY  = RGBColor(0x1B, 0x2A, 0x4A)
NAVY2 = RGBColor(0x24, 0x37, 0x5E)
BLUE  = RGBColor(0x2E, 0x75, 0xB6)
SKY   = RGBColor(0x00, 0xB0, 0xF0)
TEAL  = RGBColor(0x0E, 0x9F, 0x8A)
GREEN = RGBColor(0x2E, 0x9E, 0x6B)
RED   = RGBColor(0xC0, 0x50, 0x4D)
AMBER = RGBColor(0xD9, 0x82, 0x2B)
BG    = RGBColor(0xF4, 0xF7, 0xFB)
CARD  = RGBColor(0xFF, 0xFF, 0xFF)
DARK  = RGBColor(0x23, 0x2B, 0x36)
GRAY  = RGBColor(0x5A, 0x64, 0x72)
LIGHT = RGBColor(0xD7, 0xE1, 0xEC)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Microsoft YaHei"
W, H = Inches(13.333), Inches(7.5)

prs = Presentation()
prs.slide_width = W
prs.slide_height = H
BLANK = prs.slide_layouts[6]

# ---------------- helpers ----------------
def set_font(run, size=18, bold=False, color=DARK, italic=False, name=FONT):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = name
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find(qn('a:ea'))
    if ea is None:
        ea = etree.SubElement(rPr, qn('a:ea'))
    ea.set('typeface', name)

def no_shadow(shape):
    shape.shadow.inherit = False

def rect(slide, x, y, w, h, fill, line=None, line_w=1.0, shape=MSO_SHAPE.RECTANGLE):
    s = slide.shapes.add_shape(shape, x, y, w, h)
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = Pt(line_w)
    no_shadow(s)
    return s

def add_box(slide, x, y, w, h, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = Pt(2)
    tf.margin_right = Pt(2)
    tf.margin_top = Pt(2)
    tf.margin_bottom = Pt(2)
    return tf

def para(tf, first=False, align=PP_ALIGN.LEFT, space_after=0, space_before=0, line_spacing=1.0):
    p = tf.paragraphs[0] if first else tf.add_paragraph()
    p.alignment = align
    p.space_after = Pt(space_after)
    p.space_before = Pt(space_before)
    p.line_spacing = line_spacing
    return p

def run(p, text, size=18, bold=False, color=DARK, italic=False):
    r = p.add_run()
    r.text = text
    set_font(r, size, bold, color, italic)
    return r

def bullets(tf, items, size=15, gap=5, bcolor=SKY, bullet="\u25aa", color=DARK, line_spacing=1.05):
    first = True
    for it in items:
        p = para(tf, first=first, space_after=gap, line_spacing=line_spacing)
        first = False
        run(p, bullet + "  ", size, True, bcolor)
        if isinstance(it, tuple):
            run(p, it[0], size, it[1], color)
        else:
            run(p, it, size, False, color)
    return tf

def header(slide, title, num, kicker=None):
    rect(slide, 0, 0, W, H, BG)
    bar = rect(slide, 0, 0, W, Inches(1.02), NAVY)
    tf = bar.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.margin_left = Inches(0.55)
    tf.margin_right = Inches(0.55)
    tf.margin_top = Inches(0.02)
    tf.margin_bottom = Inches(0.02)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    run(p, title, 24, True, WHITE)
    if kicker:
        run(p, "   " + kicker, 13, False, RGBColor(0xC7, 0xD4, 0xE6))
    rect(slide, 0, Inches(1.02), W, Pt(3), SKY)
    ft = add_box(slide, Inches(0.55), Inches(7.1), Inches(8), Inches(0.32))
    run(para(ft, first=True), "SSD 存储侧模型微型化 · 孵化方案", 10, False, GRAY)
    pg = add_box(slide, Inches(12.3), Inches(7.1), Inches(0.75), Inches(0.32))
    run(para(pg, first=True, align=PP_ALIGN.RIGHT), str(num), 10, False, GRAY)

def card(slide, x, y, w, h, head, hcolor, items, size=15, gap=5, head_size=None):
    rect(slide, x, y, w, h, CARD, line=LIGHT, line_w=1.0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    hs = head_size if head_size else size + 2
    ht = add_box(slide, x + 0.28, y + 0.13, w - 0.56, Inches(0.45))
    run(para(ht, first=True), head, hs, True, hcolor)
    rect(slide, x + 0.28, y + 0.58, w - 0.56, Pt(2.5), hcolor)
    bt = add_box(slide, x + 0.28, y + 0.68, w - 0.56, h - 0.8)
    bullets(bt, items, size=size, gap=gap, bcolor=hcolor)
    return bt

def stat_card(slide, x, y, w, h, big, label, color):
    rect(slide, x, y, w, h, CARD, line=LIGHT, line_w=1.0, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(slide, x, y, w, Pt(5), color)
    tf = add_box(slide, x + 0.2, y + 0.22, w - 0.4, h - 0.3)
    run(para(tf, first=True, align=PP_ALIGN.CENTER), big, 25, True, color)
    run(para(tf, align=PP_ALIGN.CENTER, space_before=3), label, 12, False, GRAY)

# ============================================================
# Slide 1 — 封面
# ============================================================
s = prs.slides.add_slide(BLANK)
rect(s, 0, 0, W, H, NAVY)
rect(s, 0, 0, W, Inches(0.22), SKY)
rect(s, 0, H - Inches(0.22), W, Inches(0.22), SKY)
# 装饰条
rect(s, Inches(0.9), Inches(2.35), Inches(0.9), Pt(4), SKY)

tf = add_box(s, Inches(0.9), Inches(2.6), Inches(11.5), Inches(2.2))
run(para(tf, first=True), "把 AI 装进 SSD", 54, True, WHITE)
run(para(tf, space_before=6), "存储侧模型微型化 —— 让固态硬盘从“存数据”走向“懂数据”", 24, False, RGBColor(0xCF, 0xDE, 0xF0))

tf = add_box(s, Inches(0.9), Inches(4.9), Inches(11.5), Inches(0.6))
run(para(tf, first=True), "面向公司内部评审的孵化（Incubation）方案提案", 18, True, SKY)

tf = add_box(s, Inches(0.9), Inches(6.35), Inches(11.5), Inches(0.6))
run(para(tf, first=True), "汇报人：____________      部门：____________      日期：2026年__月", 14, False, RGBColor(0x9A, 0xAC, 0xC4))

# ============================================================
# Slide 2 — 目录
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "目录 · 方案总览", 2)
items = [
    ("01", "背景与问题", "数据爆炸与“数据搬运”瓶颈，AI 计算为何要靠近数据"),
    ("02", "市场与技术现状", "计算存储赛道规模、玩家、标准与模型压缩方法"),
    ("03", "现有方案优缺点", "行业已做对的事，与尚未解决的痛点"),
    ("04", "我们的方案与改进点", "面向 SSD 的一体化“微型化 + 部署”流水线"),
    ("05", "可行性论证", "为什么这件事做得成 —— 技术与生态依据"),
    ("06", "价值与收益", "成功后的效果 · 不成功也能沉淀的资产"),
    ("07", "路线图与资源", "分阶段落地计划与资源需求"),
    ("08", "总结与决策请求", "一句话主张 + 请公司做什么"),
]
x0, y0, cw, ch, gap = Inches(0.7), Inches(1.42), Inches(5.9), Inches(1.28), Inches(0.12)
for i, (no, t, d) in enumerate(items):
    col = i % 2
    row = i // 2
    x = x0 + col * (cw + gap)
    y = y0 + row * (ch + gap)
    rect(s, x, y, cw, ch, CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, x, y, Inches(0.12), ch, SKY if col == 0 else TEAL)
    tf = add_box(s, x + 0.32, y + 0.12, cw - 0.55, ch - 0.2)
    run(para(tf, first=True), no, 18, True, SKY if col == 0 else TEAL)
    run(para(tf, space_before=2), "  " + t, 15, True, DARK)
    run(para(tf, space_before=2), d, 11, False, GRAY)

# ============================================================
# Slide 3 — 背景与问题
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "背景与问题", 3, "为什么是“存储侧 AI”")
c1 = card(s, Inches(0.6), Inches(1.45), Inches(4.0), Inches(5.15), "数据侧：推理离数据越来越远", SKY, [
    "非结构化数据激增：视频、日志、传感器、向量检索",
    "AI 推理需求下沉到边缘与存储，而非集中在中心云",
    "海量原始数据“躺着”但算不到，价值被埋没",
], size=15, gap=8)
c2 = card(s, Inches(4.72), Inches(1.45), Inches(4.0), Inches(5.15), "架构痛点：数据搬运瓶颈", RED, [
    "SSD → 内存 → CPU/GPU 的搬移，带来延迟 / 带宽 / 功耗三重开销",
    "大量“就地过滤 / 特征提取”任务，被迫全量搬回主机",
    "计算离数据太远，TCO 高、实时性差",
], size=15, gap=8)
c3 = card(s, Inches(8.84), Inches(1.45), Inches(3.9), Inches(5.15), "核心机会：让存储变聪明", GREEN, [
    "把“微型化模型”直接部署到 SSD 计算引擎，就地推理",
    "存储从“被动存数据”升级为“主动懂数据”",
    "为公司在计算存储新赛道建立差异化卡位",
], size=15, gap=8)

# ============================================================
# Slide 4 — 市场与技术现状（1）
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "市场与技术现状（1）：计算存储赛道", 4)
# 顶部三张数据卡
stat_card(s, Inches(0.6), Inches(1.35), Inches(4.0), Inches(1.55), "7.04 亿美元", "2025 年全球计算存储市场规模", BLUE)
stat_card(s, Inches(4.72), Inches(1.35), Inches(4.0), Inches(1.55), "19.6 亿美元", "2032 年预计市场规模", TEAL)
stat_card(s, Inches(8.84), Inches(1.35), Inches(3.9), Inches(1.55), "15.9% CAGR", "2026–2032 复合年增长率", GREEN)

# 左：关键事实
lf = add_box(s, Inches(0.6), Inches(3.2), Inches(6.6), Inches(3.7))
run(para(lf, first=True), "赛道正在升温，但“模型”这一环缺失", 17, True, NAVY)
bullets(lf, [
    "主要玩家：Samsung、ScaleFlux、Marvell、Phison、Kioxia、Pliops、Eideticom、DapuStor、华为、忆联等",
    "标准推进：SNIA 定义计算存储设备 CSD / 处理器 CSP，划分 FCSS（固定功能）与 PCSS（可编程）",
    "2025 年 SNIA 启动 Storage.AI 项目，聚焦 AI 数据服务的开放标准",
    "应用场景：数据中心、智能摄像头、日志/检索分析、AI 数据服务",
], size=14.5, gap=7)

# 右：柱状图
cd = CategoryChartData()
cd.categories = ["2025", "2032"]
cd.add_series("市场规模（亿美元）", (7.04, 19.6))
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(7.5), Inches(3.15), Inches(5.1), Inches(3.6), cd)
ch = gf.chart
ch.has_legend = False
ch.has_title = False
plot = ch.plots[0]
plot.gap_width = 120
ser = plot.series[0]
ser.format.fill.solid()
ser.format.fill.fore_color.rgb = BLUE
plot.vary_by_categories = False
cat_ax = ch.category_axis
cat_ax.tick_labels.font.size = Pt(12)
cat_ax.tick_labels.font.name = FONT
val_ax = ch.value_axis
val_ax.tick_labels.font.size = Pt(11)
val_ax.has_major_gridlines = True
tf = add_box(s, Inches(7.5), Inches(6.75), Inches(5.1), Inches(0.3))
run(para(tf, first=True, align=PP_ALIGN.CENTER), "数据来源：LP Information / QYResearch 计算存储市场报告", 9.5, False, GRAY)

# ============================================================
# Slide 5 — 市场与技术现状（2）
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "市场与技术现状（2）：技术路线盘点", 5)
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(2.6), "计算存储硬件", SKY, [
    "在 SSD / 存储控制器内部集成 FPGA / ASIC 加速器，靠近 NAND 计算",
    "代表：Samsung SmartSSD（FPGA）、ScaleFlux、Pliops、DapuStor 等",
], size=14, gap=6)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(2.6), "软件与服务标准", BLUE, [
    "FCSS：固定功能（压缩 / 加密 / 过滤 / 检索）",
    "PCSS：可编程计算服务，支持自定义算子",
], size=14, gap=6)
card(s, Inches(0.6), Inches(4.2), Inches(6.0), Inches(2.6), "模型微型化技术（模型侧）", TEAL, [
    "量化（INT8 / INT4）、剪枝、知识蒸馏",
    "轻量架构（YOLO / MobileNet 系列）、NAS 结构搜索",
], size=14, gap=6)
card(s, Inches(6.85), Inches(4.2), Inches(5.9), Inches(2.6), "关键观察 —— 我们的切入点", AMBER, [
    "硬件侧“有算力、缺模型”；模型侧“有压缩、缺落地”",
    "二者缺少系统化衔接，这正是我们方案要补的空白",
], size=14, gap=6)

# ============================================================
# Slide 6 — 现有方案优缺点
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "现有方案优缺点", 6)
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(5.35), "优点 · 行业已验证的价值", GREEN, [
    "就地处理，减少数据搬移 → 更低延迟、更省带宽",
    "卸载主机 CPU，降低整体能耗与 TCO",
    "数据不出盘，隐私与合规更友好",
    "贴近数据源，天然适合过滤 / 检索 / 特征提取",
    "已有商用产品与标准背书，路线被验证",
], size=15, gap=9)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(5.35), "缺点与痛点 · 尚未解决的问题", RED, [
    "硬件成本高、生态碎片化，各家私有 SDK，迁移难",
    "SSD 内算力弱、内存小、功耗预算紧，大模型放不进去",
    "缺“模型 → 存储计算引擎”的成熟部署工具链",
    "参照案例 SmartSSD 商业落地不及预期，热度曾被生成式 AI 冲淡",
], size=15, gap=9)

# ============================================================
# Slide 7 — 我们的方案与改进点
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "我们的方案与改进点", 7)
bar = rect(s, Inches(0.6), Inches(1.35), Inches(12.13), Inches(1.0), NAVY2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(1.4), Inches(11.6), Inches(0.9), anchor=MSO_ANCHOR.MIDDLE)
p = para(tf, first=True)
run(p, "方案总述：", 15, True, SKY)
run(p, "面向 SSD 存储计算引擎，打造一套“模型微型化 + 自动部署”一体化流水线，把任意模型定制成能在盘内实时推理的轻量模型。", 15, False, WHITE)

card(s, Inches(0.6), Inches(2.55), Inches(6.0), Inches(2.25), "① 硬件感知的自动微型化", SKY, [
    "量化 + 剪枝 + 蒸馏 + NAS，针对具体 SSD 的算力 / 内存 / 功耗约束定制模型",
], size=13.5, gap=4)
card(s, Inches(6.85), Inches(2.55), Inches(5.9), Inches(2.25), "② 统一中间表示与运行时", BLUE, [
    "抽象各家硬件差异，一次压缩、多端部署，摆脱私有 SDK 锁定",
], size=13.5, gap=4)
card(s, Inches(0.6), Inches(4.95), Inches(6.0), Inches(1.9), "③ 多目标联合优化", TEAL, [
    "精度 - 延迟 - 能效三目标联合优化，结果可量化、可复现",
], size=13.5, gap=4)
card(s, Inches(6.85), Inches(4.95), Inches(5.9), Inches(1.9), "④ 分级混合推理", GREEN, [
    "轻任务就地推理，重任务自动回退主机，保证精度兜底",
], size=13.5, gap=4)

# ============================================================
# Slide 8 — 可行性论证
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "可行性论证", 8, "为什么这件事做得成")
card(s, Inches(0.6), Inches(1.4), Inches(6.0), Inches(2.55), "技术可行", SKY, [
    "量化 / 剪枝 / 蒸馏已成熟，可在 2–4 倍压缩下保持精度",
    "TinyML 已证明 mW 级端侧推理可行",
], size=14, gap=6)
card(s, Inches(6.85), Inches(1.4), Inches(5.9), Inches(2.55), "硬件可行", BLUE, [
    "SSD 控制器算力持续提升（多核 ARM / NPU），已能承载轻量模型",
    "存储厂商正加速内建加速器",
], size=14, gap=6)
card(s, Inches(0.6), Inches(4.15), Inches(6.0), Inches(2.55), "需求真实", TEAL, [
    "就地过滤 / 特征提取是数据库、检索、安全监控的普遍刚需",
    "客户愿意为“省带宽、低延迟、隐私”付费",
], size=14, gap=6)
card(s, Inches(6.85), Inches(4.15), Inches(5.9), Inches(2.55), "生态有利", GREEN, [
    "SNIA 标准降低集成门槛，我们可复用模型侧积累",
    "先发者可形成工具链壁垒",
], size=14, gap=6)

# ============================================================
# Slide 9 — 成功后的效果
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "成功后的效果", 9, "做成了，我们能得到什么")
card(s, Inches(0.6), Inches(1.4), Inches(4.0), Inches(3.5), "业务价值", SKY, [
    "新产品形态：智能 SSD / 计算存储服务",
    "在竞争激烈的存储市场中形成差异化卖点",
], size=14, gap=7)
card(s, Inches(4.72), Inches(1.4), Inches(4.0), Inches(3.5), "技术价值", BLUE, [
    "端到端微型化工具链沉淀为核心 IP",
    "可迁移到手机、IoT、边缘服务器等场景",
], size=14, gap=7)
card(s, Inches(8.84), Inches(1.4), Inches(3.9), Inches(3.5), "商业价值", GREEN, [
    "切入 CAGR 15.9% 的高增长计算存储赛道",
    "抢占“模型 + 存储”先机，建立护城河",
], size=14, gap=7)

rect(s, Inches(0.6), Inches(5.0), Inches(12.13), Inches(1.78), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(5.12), Inches(11.6), Inches(1.55))
run(para(tf, first=True), "量化预期（示意，以基准测试为准）", 15, True, NAVY)
bullets(tf, [
    ("数据搬移量显著下降", True),
    ("端到端延迟下降", True),
    ("主机 CPU 负载下降", True),
    ("总体拥有成本 TCO 下降", True),
    ("精度损失可控（混合推理兜底）", True),
], size=13, gap=1, bcolor=SKY)

# ============================================================
# Slide 10 — 不成功也能获得的收益
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "不成功也能获得的收益", 10, "失败是“带资产”的失败")
rows = [
    ("可复用资产", "量化 / 剪枝 / 蒸馏 / NAS 工具链，可直接迁移至手机、IoT、边缘服务器等端侧场景", SKY),
    ("方法论沉淀", "近存 / 计算存储的软硬件协同工程经验与选型依据，避免后续重复踩坑", BLUE),
    ("决策依据", "明确“能做什么、不能做什么”的技术边界，为后续投入方向提供数据", TEAL),
    ("行业卡位", "论文 / 专利 / 行业标准参与，建立行业影响力与话语权", GREEN),
    ("团队成长", "跨“算法 × 存储 × 固件”的复合能力建设，人才复用价值高", AMBER),
]
y = 1.4
for name, desc, col in rows:
    rect(s, Inches(0.6), Inches(y), Inches(12.13), Inches(1.0), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, Inches(0.6), Inches(y), Inches(0.14), Inches(1.0), col)
    tf = add_box(s, Inches(1.0), Inches(y + 0.14), Inches(3.0), Inches(0.75), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf, first=True), name, 16, True, col)
    tf2 = add_box(s, Inches(4.05), Inches(y + 0.12), Inches(8.4), Inches(0.8), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf2, first=True), desc, 13.5, False, DARK)
    y += 1.12

# ============================================================
# Slide 11 — 路线图与资源
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "路线图与资源", 11)
phases = [
    ("Phase 0", "1–2 月", "调研与可行性验证", "锁定目标 SSD 平台与高价值场景，产出可行性结论", SKY),
    ("Phase 1", "3–6 月", "原型验证", "跑通“微型化 → 部署 → 盘内推理”全链路", BLUE),
    ("Phase 2", "6–9 月", "基准测试与调优", "产出可演示 demo 与完整性能 / 精度数据", TEAL),
    ("Phase 3", "9–12 月", "产品化与试点", "集成到产品线，落地试点客户验证", GREEN),
]
x0, cw, ch, gap = Inches(0.6), Inches(2.92), Inches(3.2), Inches(0.15)
for i, (ph, tm, t, d, col) in enumerate(phases):
    x = x0 + i * (cw + gap)
    rect(s, x, Inches(1.45), cw, ch, CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    rect(s, x, Inches(1.45), cw, Inches(0.62), col)
    tf = add_box(s, x + 0.16, Inches(1.5), cw - 0.32, Inches(0.5))
    run(para(tf, first=True), ph + "  ·  " + tm, 15, True, WHITE)
    tf = add_box(s, x + 0.16, Inches(2.25), cw - 0.32, Inches(0.5))
    run(para(tf, first=True), t, 16, True, DARK)
    tf = add_box(s, x + 0.16, Inches(2.75), cw - 0.32, Inches(1.7))
    run(para(tf, first=True), d, 12.5, False, GRAY)

rect(s, Inches(0.6), Inches(5.0), Inches(12.13), Inches(1.75), CARD, line=LIGHT, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
tf = add_box(s, Inches(0.9), Inches(5.15), Inches(11.6), Inches(1.5))
run(para(tf, first=True), "资源需求", 16, True, NAVY)
bullets(tf, [
    "团队：小规模跨职能孵化组（算法 + 存储固件 + 系统，约 5–8 人）",
    "预算：样机与算力资源 + 基础运营经费，按阶段评审拨付",
    "治理：每阶段设明确里程碑与止损闸门（go / no-go）",
], size=13.5, gap=5, bcolor=SKY)

# ============================================================
# Slide 12 — 风险与应对
# ============================================================
s = prs.slides.add_slide(BLANK)
header(s, "风险与应对", 12)
rows_data = [
    ("风险", "影响", "应对策略"),
    ("硬件生态碎片化", "高", "以 SNIA 标准 + 统一中间表示抽象隔离，聚焦主流平台"),
    ("微型化后精度损失", "中", "多目标联合优化 + 分级混合推理兜底，精度可测可控"),
    ("商业落地周期较长", "中", "先聚焦检索 / 日志分析 / 安全监控等高价值场景快速验证"),
    ("资源与周期约束", "中", "分阶段交付、里程碑评审、快速止损机制"),
]
tbl_shape = s.shapes.add_table(5, 3, Inches(0.6), Inches(1.5), Inches(12.13), Inches(4.4))
tbl = tbl_shape.table
tbl.columns[0].width = Inches(3.3)
tbl.columns[1].width = Inches(1.6)
tbl.columns[2].width = Inches(7.23)
for r in range(5):
    tbl.rows[r].height = Inches(0.75 if r == 0 else 0.92)
for r, row in enumerate(rows_data):
    for c, val in enumerate(row):
        cell = tbl.cell(r, c)
        cell.margin_left = Inches(0.15)
        cell.margin_right = Inches(0.1)
        cell.margin_top = Inches(0.05)
        cell.margin_bottom = Inches(0.05)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        if r == 0:
            cell.fill.solid(); cell.fill.fore_color.rgb = NAVY
            run(p, val, 15, True, WHITE)
        else:
            cell.fill.solid(); cell.fill.fore_color.rgb = WHITE if r % 2 == 1 else RGBColor(0xEE, 0xF3, 0xF9)
            if c == 1:
                p.alignment = PP_ALIGN.CENTER
                col = RED if val == "高" else AMBER
                run(p, val, 14, True, col)
            elif c == 0:
                run(p, val, 14.5, True, DARK)
            else:
                run(p, val, 13.5, False, DARK)

# ============================================================
# Slide 13 — 总结与决策请求
# ============================================================
s = prs.slides.add_slide(BLANK)
rect(s, 0, 0, W, H, NAVY)
rect(s, 0, 0, W, Inches(0.22), SKY)
tf = add_box(s, Inches(0.9), Inches(1.15), Inches(11.5), Inches(1.9))
run(para(tf, first=True), "一句话主张", 15, True, SKY)
run(para(tf, space_before=10), "用“模型微型化”补齐计算存储落地的最后一块拼图，", 30, True, WHITE)
run(para(tf), "让 SSD 从“存数据”走向“懂数据”。", 30, True, WHITE)

tf = add_box(s, Inches(0.9), Inches(3.5), Inches(11.5), Inches(0.5))
run(para(tf, first=True), "请求公司决策", 15, True, SKY)

asks = [
    "批准立项，组建小规模孵化团队（算法 + 存储固件 + 系统）",
    "提供预算、算力与样机等基础资源支持",
    "明确里程碑评审节点（Phase 1 原型 / Phase 2 Demo），按期 go / no-go",
]
y = 4.05
for i, a in enumerate(asks):
    rect(s, Inches(0.9), Inches(y), Inches(11.5), Inches(0.72), NAVY2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf = add_box(s, Inches(1.2), Inches(y + 0.08), Inches(11.0), Inches(0.56), anchor=MSO_ANCHOR.MIDDLE)
    run(para(tf, first=True), f"{i+1}.  {a}", 16, False, WHITE)
    y += 0.86

tf = add_box(s, Inches(0.9), Inches(6.7), Inches(11.5), Inches(0.5))
run(para(tf, first=True), "谢谢 · 期待评审意见", 16, True, SKY)

# ---------------- save ----------------
prs.core_properties.title = "SSD 存储侧模型微型化 · 孵化方案"
prs.core_properties.author = "Incubation Team"
prs.core_properties.subject = "计算存储 + 模型微型化 孵化提案"
out = "SSD存储侧模型微型化_孵化方案_v2.pptx"
prs.save(out)
print("saved:", out, "slides:", len(prs.slides.__iter__.__self__._sldIdLst))
