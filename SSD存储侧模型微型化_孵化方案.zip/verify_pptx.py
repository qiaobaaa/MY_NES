# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding="utf-8")
from pptx import Presentation
from pptx.util import Emu

p = Presentation("SSD存储侧模型微型化_孵化方案.pptx")
print("SLIDE COUNT:", len(p.slides.__iter__.__self__._sldIdLst))
for i, slide in enumerate(p.slides, 1):
    print("\n===== SLIDE %d =====" % i)
    for shape in slide.shapes:
        if shape.has_text_frame:
            txt = "\n".join(r.text for para in shape.text_frame.paragraphs for r in para.runs)
            t = txt.strip()
            if t:
                print("  [TXT]", t[:200].replace("\n", " | "))
        if shape.has_table:
            tb = shape.table
            print("  [TABLE] rows=%d cols=%d" % (len(tb.rows), len(tb.columns)))
            for row in tb.rows:
                print("     ", " || ".join(c.text for c in row.cells))
        if shape.has_chart:
            ch = shape.chart
            cats = list(ch.plots[0].categories)
            vals = list(ch.plots[0].series[0].values)
            print("  [CHART]", cats, vals)
